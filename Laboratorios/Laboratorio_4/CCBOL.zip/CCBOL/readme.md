# Instrucciones para ejecutar el programa con Nodemon

Para ejecutar el programa "app" utilizando Nodemon o node, sigue estos pasos:


1. Abre una terminal o línea de comandos y ejecuta:

    ```bash
    nodemon app o node app
    ```

3. Instala Nodemon globalmente si aún no lo has hecho ejecutando el siguiente comando:

    ```bash
    npm install -g nodemon
    ```
   
